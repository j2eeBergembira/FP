package org.riays.repository;

import org.riays.domain.*;
import java.util.List;

public interface PersonRepository {
	
	public List <Person> findAll();
	public void add(Person p);
}
