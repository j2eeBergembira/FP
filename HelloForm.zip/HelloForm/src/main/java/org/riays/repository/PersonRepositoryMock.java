package org.riays.repository;
import java.util.ArrayList;

import java.util.List;

import org.riays.domain.*;
import org.springframework.stereotype.Service;

@Service
public class PersonRepositoryMock implements PersonRepository{
		private List<Person> persons = new ArrayList<Person>();
		
		public PersonRepositoryMock() {
			String[] hobbies = {"programming", "watching movies"};
			persons.add(new Person("Abdul Munif", 27, hobbies, "Male", "Kediri"));
			persons.add(new Person("Rizky Januar Akbar", 26, hobbies, "Male", "Bandung"));
		}
		@Override
		public List<Person> findAll() {
			// TODO Auto-generated method stub
			return persons;
		}

		@Override
		public void add(Person p) {
			// TODO Auto-generated method stub
			persons.add(p);
		}
		
		
}
		