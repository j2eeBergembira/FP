package org.riays.repository;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;
@Service
public class FormRepositoryMock implements FormRepository{
	List <String> genders = new ArrayList<String>();
	List <String> hobbies = new ArrayList<String>();
	List <String> origins = new ArrayList<String>();
	public FormRepositoryMock(){
		//genders
		genders.add("Male");
		genders.add("Female");
		//hobbies
		hobbies.add("Reading");
		hobbies.add("Watching");
		//origin
		origins.add("Surabaya");
		origins.add("Jakarta");
	}
	@Override
	public List<String> getGenders() {
		// TODO Auto-generated method stub
		return genders;
	}
	@Override
	public List<String> getHobbies() {
		// TODO Auto-generated method stub
		return hobbies;
	}
	@Override
	public List<String> getOrigins() {
		// TODO Auto-generated method stub
		return origins;
	}
	
}
