package org.riays.repository;

import java.util.List;

public interface FormRepository {
	List<String> getGenders();
	List<String> getHobbies();
	List<String> getOrigins();
}
