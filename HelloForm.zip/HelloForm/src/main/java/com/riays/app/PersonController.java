package com.riays.app;

import org.riays.domain.Person;
import org.riays.repository.FormRepository;
import org.riays.repository.PersonRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class PersonController {
	@Autowired
	private PersonRepository personRepository;
	@Autowired
	private FormRepository formRepository;
	@RequestMapping(value="/person/list", method = RequestMethod.GET)
	public ModelAndView personList(){
		ModelAndView mav = new ModelAndView();
		mav.setViewName("/person/list");
		mav.addObject("persons", personRepository.findAll());
		mav.addObject("personBean", new Person());
		mav.addObject("hobbies", formRepository.getHobbies());
		mav.addObject("genders", formRepository.getGenders());
		mav.addObject("origins", formRepository.getOrigins());
		return mav;
	}
	@RequestMapping(value="/person/add", method = RequestMethod.POST)
	public ModelAndView personAdd(@ModelAttribute Person p) {
		ModelAndView mav = new ModelAndView();
		
		//add persons
		personRepository.add(p);
		
		//redirect to /person/list
		mav.setViewName("redirect:/person/list");
		return mav;
	}
}
